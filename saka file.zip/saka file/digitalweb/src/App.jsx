import { BrowserRouter } from "react-router-dom";
import Navbar from "./components/navbar";
import AppRouter from "./router/Approuter"; // ya AppRouter.jsx (rename karoge to)

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <AppRouter />
    </BrowserRouter>
  );
}

export default App;