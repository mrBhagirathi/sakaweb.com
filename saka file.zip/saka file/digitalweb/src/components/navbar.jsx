import { NavLink } from "react-router-dom";
import { motion } from "framer-motion";
import { useState } from "react";

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { name: "Home", path: "/" },
    { name: "About", path: "/about" },
    { name: "Contact", path: "/contact" },
    { name: "Career", path: "/career" },
    { name: "Industry", path: "/industry" },
  ];

  return (
    <motion.nav
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="w-full bg-black/90 backdrop-blur-md text-white shadow-md border-b border-gray-800 sticky top-0 z-50"
    >
      <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">

        {/* Logo */}
        <h1 className="text-xl font-bold tracking-wide">
          MyCompany
        </h1>

        {/* Desktop Menu */}
        <ul className="hidden md:flex gap-8 text-sm relative">
          {navItems.map((item, i) => (
            <li key={i} className="relative group">
              <NavLink to={item.path}>
                {({ isActive }) => (
                  <div className="relative px-2 py-1">
                    
                    {/* Text */}
                    <span
                      className={`relative z-10 transition ${
                        isActive
                          ? "text-white font-semibold"
                          : "text-gray-300 group-hover:text-white"
                      }`}
                    >
                      {item.name}
                    </span>

                    {/* Apple Style Active Background */}
                    {isActive && (
                      <motion.div
                        layoutId="active-pill"
                        className="absolute inset-0 bg-white/10 rounded-md"
                        transition={{ type: "spring", stiffness: 300, damping: 25 }}
                      />
                    )}

                    {/* Gradient Glow */}
                    <span className="absolute inset-0 rounded-md bg-gradient-to-r from-blue-500 to-purple-500 opacity-0 group-hover:opacity-20 blur-md transition"></span>

                  </div>
                )}
              </NavLink>
            </li>
          ))}
        </ul>

        {/* Mobile Button */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="md:hidden text-2xl"
        >
          ☰
        </button>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          className="md:hidden bg-black px-6 pb-4"
        >
          {navItems.map((item, i) => (
            <NavLink
              key={i}
              to={item.path}
              onClick={() => setMenuOpen(false)}
              className="block py-2 text-gray-300 hover:text-white"
            >
              {item.name}
            </NavLink>
          ))}
        </motion.div>
      )}
    </motion.nav>
  );
}

export default Navbar;