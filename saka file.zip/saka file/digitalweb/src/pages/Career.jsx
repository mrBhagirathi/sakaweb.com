function Career() {
  return <h1 className="p-10 text-3xl">Career Page</h1>;
}
export default Career;