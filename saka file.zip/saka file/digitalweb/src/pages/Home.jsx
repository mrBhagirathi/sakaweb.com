import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useState } from "react";

export default function Home() {
  const { scrollY } = useScroll();

  // 🌊 Parallax
  const yText = useTransform(scrollY, [0, 400], [0, -120]);
  const opacity = useTransform(scrollY, [0, 250], [1, 0]);

  // 🎯 Cursor Glow
  const [pos, setPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const move = (e) => {
      setPos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, []);

  // 🎥 Video Slider
  const videos = ["/vdo1.mp4", "/vdo2.mp4"];
  const [index, setIndex] = useState(0);

  // 🔄 Auto Slide
  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % videos.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-black text-white overflow-hidden relative">

      {/* 🎯 Cursor Glow */}
      <motion.div
        animate={{ x: pos.x - 150, y: pos.y - 150 }}
        transition={{ duration: 0.2 }}
        className="fixed w-[300px] h-[300px] bg-blue-500 opacity-20 blur-3xl rounded-full pointer-events-none z-0"
      />

      {/* 🚀 HERO */}
      <section className="relative h-screen flex items-center justify-center text-center overflow-hidden">

        {/* 🎥 VIDEO BACKGROUND */}
        <div className="absolute inset-0 z-0">
          {videos.map((video, i) => (
            <motion.video
              key={i}
              src={video}
              autoPlay
              muted
              loop
              playsInline
              className="absolute w-full h-full object-cover"
              initial={{ opacity: 0 }}
              animate={{ opacity: index === i ? 1 : 0 }}
              transition={{ duration: 1 }}
            />
          ))}

          {/* DARK OVERLAY */}
          <div className="absolute inset-0 bg-black/60" />
        </div>

        {/* ✨ HERO CONTENT */}
        <motion.div
          style={{ y: yText, opacity }}
          className="relative z-10 px-6 max-w-3xl"
        >
          <h1 className="text-4xl md:text-6xl font-bold leading-tight">
            Build Smart Digital Products with AI 🚀
          </h1>

          <p className="mt-4 text-gray-300">
            We help businesses scale with modern web, cloud & AI solutions.
          </p>

          <motion.button
            whileHover={{ scale: 1.1 }}
            className="mt-6 px-6 py-3 bg-blue-500 rounded-full text-lg"
          >
            Get Started
          </motion.button>
        </motion.div>

        {/* 🔘 SLIDER DOTS */}
        <div className="absolute bottom-8 flex gap-3 z-10">
          {videos.map((_, i) => (
            <button
              key={i}
              onClick={() => setIndex(i)}
              className={`w-3 h-3 rounded-full transition ${
                index === i ? "bg-blue-500 scale-125" : "bg-gray-500"
              }`}
            />
          ))}
        </div>

      </section>
    </div>
  );
}